#ifndef __SPI_H__
#define __SPI_H__

void SPIInit(void);
#endif
